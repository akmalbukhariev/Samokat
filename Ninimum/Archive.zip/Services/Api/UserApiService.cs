
using Models.Requests;
using Models.Responses;
using Newtonsoft.Json;
using Ninimum.Models;
using RestSharp;
using Utils;

namespace Api.Services
{
    public class UserApiService : ApiService
    {
        #region Url
        private const string BASE_URL = "";
        //private const string BASE_URL = "/ninimum/api/v1/";
        private const string LOGIN_USER = $"{BASE_URL}user/login";
        private const string CHECK_PHONE_NUMBER = $"{BASE_URL}user/checkPhoneNumber";
        private const string LOGOUT_USER = $"{BASE_URL}user/logout";
        private const string REGISTER_USER = $"{BASE_URL}user/register";
        private const string GET_REGIONS = $"{BASE_URL}region/getRegions";
        private const string GET_USER_INFO = $"{BASE_URL}user/getUserInfo";
        private const string UPDATE_USER_PASSWORD = $"{BASE_URL}user/forgotPassword";
        private const string CHANGE_PASSWORD = $"{BASE_URL}user/changePassword";
        private const string GET_USER_LIST = $"{BASE_URL}user/getUserByIdList";
        private const string UPDATE_USER_INFO = $"{BASE_URL}user/updateUserInfo";
        private const string CHANGE_REGION = $"{BASE_URL}user/changeRegion";
        private const string UPDATE_USER_PHONE_NUMBER = $"{BASE_URL}user/updateUserPhoneNumber";
        private const string CHANGE_PHONE_NUMBER = $"{BASE_URL}user/changePhoneNumber";
        private const string DELETE_USER_ACCOUNT = $"{BASE_URL}user/deleteAccount";
        private const string VERIFY_NUMBER = $"{BASE_URL}message/verifyPhoneNumber";
        private const string SEND_TEMP_PASSWORD = $"{BASE_URL}message/sendTemporaryPassword";
        private const string GET_PRODUCT_LIST = $"{BASE_URL}product/getProductList";
        private const string SEARCH_PRODUCT_LIST = $"{BASE_URL}product/searchProductList";
        private const string ADD_FAVORITE_PRODUCT = $"{BASE_URL}favorite/addFavorite";
        private const string DELETE_FAVORITE_PRODUCT = $"{BASE_URL}favorite/deleteFavorite";
        private const string GET_FAVORITE_PRODUCT = $"{BASE_URL}favorite/getFavoriteList";
        private const string GET_BANNER_LIST = $"{BASE_URL}banner/getBannerList";
        private const string GET_PRODUCT_DETAIL = $"{BASE_URL}product/getProductDetail";
        private const string GET_SIMILAR_PRODUCT_LIST = $"{BASE_URL}product/getSimilarProductList";
        private const string GET_PRODUCT_REVIEW_LIST = $"{BASE_URL}review/getReviewList";
        private const string GET_REVIEW_ELIGIBILITY = $"{BASE_URL}review/getReviewEligibility";
        private const string ADD_REVIEW = $"{BASE_URL}review/addReview";
        private const string UPDATE_REVIEW = $"{BASE_URL}review/updateReview";
        private const string GET_PRODUCT_QUESTION_LIST = $"{BASE_URL}product-question/getQuestionList";
        private const string ADD_PRODUCT_QUESTION = $"{BASE_URL}product-question/addQuestion";
        private const string ADD_CART_PRODUCT = $"{BASE_URL}cart/addCart";
        private const string GET_CART_LIST = $"{BASE_URL}cart/getCartList";
        private const string DELETE_CART_LIST = $"{BASE_URL}cart/deleteCart";
        private const string CREATE_PAYMENT_CARD = $"{BASE_URL}payment/createPaymentCard";
        private const string GET_PAYMENT_CARD_LIST = $"{BASE_URL}payment/getPaymentCardList";
        private const string DELETE_PAYMENT_CARD = $"{BASE_URL}payment/deletePaymentCard";
        private const string SET_DEFAULT_PAYMENT_CARD = $"{BASE_URL}payment/setDefaultPaymentCard";
        private const string CREATE_ORDER = $"{BASE_URL}order/createOrder";
        private const string GET_PAYME_CHEKOUT_URL = $"{BASE_URL}payment/payme/createCheckoutUrl";
        private const string GET_ORDER_PAYMENT_STATUS = $"{BASE_URL}order/getOrderPaymentStatus";
        private const string GET_ORDER_PROCESS = $"{BASE_URL}order/getOrderProcess";
        private const string GET_ORDER_LIST = $"{BASE_URL}order/getOrderList";
        private const string GET_ORDER_DETAIL = $"{BASE_URL}order/getOrderDetail";
        private const string CANCEL_ORDER = $"{BASE_URL}order/cancelOrder";
        private const string CANCEL_UNPAID_ORDER = $"{BASE_URL}order/cancelUnpaidOrder";
        private const string GET_ACTIVE_SUBSCRIPTION = $"{BASE_URL}subscription/getActiveSubscription";
        private const string GET_SUBSCRIPTION_LIST = $"{BASE_URL}subscription/getSubscriptionList";
        private const string GET_TARIFF_LIST = $"{BASE_URL}tariff/getTariffList";
        private const string CREATE_TARIFF_CHECKOUT = $"{BASE_URL}subscription/payme/createCheckoutUrl";
        private const string GET_TARIFF_PAYMENT_STATUS = $"{BASE_URL}subscription/getPaymentStatus";
        private const string CANCEL_SUBSCRIPTION = $"{BASE_URL}subscription/cancelSubscription";
        private const string DELETE_ORDER_HISTORY = $"{BASE_URL}order/deleteOrderHistory";
        #endregion

        public UserApiService(RestClient client)
            : base(client)
        {

        }

        public async Task<RegionListResponse> GetRegions()
        {
            var response = new RegionListResponse();

            try
            {
                var receivedData = await GetAsync(GET_REGIONS, false);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<RegionListResponse>(receivedData);

                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<LoginUserResponse> Login(LoginUserRequest data)
        {
            var response = await LoginAsync<LoginUserResponse>(LOGIN_USER, data);

            return response ?? new LoginUserResponse
            {
                resultCode = ApiResult.FAILED.GetCodeToString(),
                resultMsg = ApiResult.FAILED.GetMessage()
            };
        }

        public async Task<Response> DeleteUserAccount(DeleteAccountRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await DeleteAsync(DELETE_USER_ACCOUNT, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> LogOut()
        {
            var response = new Response();

            try
            {
                var receivedData = await PostAsync(LOGOUT_USER, null, false);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> ChangeRegion(ChangeRegionRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PutAsync(CHANGE_REGION, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<Response>(receivedData);

                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> UpdateUserPhoneNumber(string new_phone_number)
        {
            var response = new Response();

            try
            {
                var receivedData = await PostAsync($"{UPDATE_USER_PHONE_NUMBER}/{new_phone_number}", null, false);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> UpdateUserPassword(ForgotPasswordParam data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PostAsync(UPDATE_USER_PASSWORD, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }
    
        public async Task<Response> ChangePhoneNumber(ChangePhoneNumberRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PutAsync(CHANGE_PHONE_NUMBER, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> ChangePassword(ChangePasswordRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PutAsync(CHANGE_PASSWORD, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> RegisterUser(RegisterUserRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PostAsync(REGISTER_USER, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<string> GetAddressFromYandexAsync(double latitude, double longitude)
        {
            try
            {
                const string apiKey = "bb9a670d-13db-4cec-8fc9-a03c8b2b4ece";

                var url =
                    $"https://geocode-maps.yandex.ru/v1/?" +
                    $"apikey={apiKey}" +
                    $"&geocode={longitude},{latitude}" +
                    $"&lang=en_US" +
                    $"&format=json";

                using var httpClient = new HttpClient();

                var json = await httpClient.GetStringAsync(url);

                dynamic result = JsonConvert.DeserializeObject(json);

                string address =
                    result.response.GeoObjectCollection.featureMember[0]
                        .GeoObject.metaDataProperty.GeocoderMetaData.text;

                return address;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Yandex address error: {ex.Message}");
                return string.Empty;
            }
        }

        public async Task<SelectedAddressModel?> SearchAddressInQashqadaryoAsync(string query)
        {
            if (string.IsNullOrWhiteSpace(query))
                return null;

            try
            {
                const string apiKey = "bb9a670d-13db-4cec-8fc9-a03c8b2b4ece";
                const string bbox = "64.10,37.85~67.85,39.70";

                string trimmedQuery = query.Trim();
                string lowerQuery = trimmedQuery.ToLowerInvariant();

                bool alreadyHasRegionContext =
                    lowerQuery.Contains("qashqadaryo") ||
                    lowerQuery.Contains("kashkadarya") ||
                    lowerQuery.Contains("uzbekistan");

                string searchText = alreadyHasRegionContext
                    ? trimmedQuery
                    : $"{trimmedQuery}, Qashqadaryo, Uzbekistan";

                string encodedSearchText = Uri.EscapeDataString(searchText);

                var url =
                    $"https://geocode-maps.yandex.ru/v1/?" +
                    $"apikey={apiKey}" +
                    $"&geocode={encodedSearchText}" +
                    $"&bbox={bbox}" +
                    $"&rspn=1" +
                    $"&results=1" +
                    $"&lang=en_US" +
                    $"&format=json";

                using var httpClient = new HttpClient();
                var json = await httpClient.GetStringAsync(url);

                dynamic? result = JsonConvert.DeserializeObject(json);
                var featureMembers = result?.response?.GeoObjectCollection?.featureMember;

                if (featureMembers == null || featureMembers.Count == 0)
                    return null;

                dynamic geoObject = featureMembers[0].GeoObject;
                string position = geoObject.Point.pos;
                string address = geoObject.metaDataProperty.GeocoderMetaData.text;

                string[] parts = position.Split(
                    ' ',
                    StringSplitOptions.RemoveEmptyEntries);

                if (parts.Length != 2 ||
                    !double.TryParse(parts[0], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double longitude) ||
                    !double.TryParse(parts[1], System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out double latitude))
                {
                    return null;
                }

                return new SelectedAddressModel
                {
                    Address = address,
                    Latitude = latitude,
                    Longitude = longitude
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Yandex address search error: {ex.Message}");
                return null;
            }
        }

        public async Task<VerifyPhoneNumberResponse> VerifyNumber(VerifyPhoneNumberRequest data)
        {
            var response = new VerifyPhoneNumberResponse();

            try
            {
                var receivedData = await PostAsync(VERIFY_NUMBER, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<VerifyPhoneNumberResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<VerifyPhoneNumberResponse> SendTempPassword(VerifyPhoneNumberRequest data)
        {
            var response = new VerifyPhoneNumberResponse();

            try
            {
                var receivedData = await PostAsync(SEND_TEMP_PASSWORD, data, useToken: false);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<VerifyPhoneNumberResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<CheckPhoneNumberResponse> CheckPhoneNumber(CheckPhoneNumberRequest data)
        {
            var response = new CheckPhoneNumberResponse();

            try
            {
                var receivedData = await PostAsync(CHECK_PHONE_NUMBER, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<CheckPhoneNumberResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<BannerListResponse> GetBannerList()
        {
            var response = new BannerListResponse();

            try
            {
                var receivedData = await GetAsync(GET_BANNER_LIST);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<BannerListResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<ProductResponse> GetProductList(ProductListRequest data)
        {
            var response = new ProductResponse();

            try
            {
                var receivedData = await PostAsync(GET_PRODUCT_LIST, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<ProductResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<DetailProductResponse> GetProductDetail(ProductDetailRequest data)
        {
            var response = new DetailProductResponse();

            try
            {
                var receivedData = await PostAsync(GET_PRODUCT_DETAIL, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<DetailProductResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<ProductResponse> GetSimilarProduct(SimilarProductListRequest data)
        {
            var response = new ProductResponse();

            try
            {
                var receivedData = await PostAsync(GET_SIMILAR_PRODUCT_LIST, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<ProductResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<ReviewProductResponse> GetProductReviewList(ReviewListRequest data)
        {
            var response = new ReviewProductResponse();

            try
            {
                var receivedData = await PostAsync(GET_PRODUCT_REVIEW_LIST, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<ReviewProductResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<ReviewEligibilityResponse> GetReviewEligibility(ReviewEligibilityRequest data)
        {
            var response = new ReviewEligibilityResponse();
            try
            {
                var receivedData = await PostAsync(GET_REVIEW_ELIGIBILITY, data);
                if (!string.IsNullOrWhiteSpace(receivedData))
                    return JsonConvert.DeserializeObject<ReviewEligibilityResponse>(receivedData) ?? response;
            }
            catch (Exception ex)
            {
                response.resultMsg = $"API: {ex.Message}";
            }
            return response;
        }

        public async Task<Response> AddProductReview(AddReviewRequest data, IReadOnlyList<FileResult>? images = null)
        {
            var response = new Response();
            try
            {
                var receivedData = await PostMultipartAsync(ADD_REVIEW, data, images);
                if (!string.IsNullOrWhiteSpace(receivedData))
                    return JsonConvert.DeserializeObject<Response>(receivedData) ?? response;
            }
            catch (Exception ex)
            {
                response.resultMsg = $"API: {ex.Message}";
            }
            return response;
        }

        public async Task<Response> UpdateProductReview(UpdateReviewRequest data, IReadOnlyList<FileResult>? images = null)
        {
            var response = new Response();
            try
            {
                var receivedData = await PostMultipartAsync(UPDATE_REVIEW, data, images);
                if (!string.IsNullOrWhiteSpace(receivedData))
                    return JsonConvert.DeserializeObject<Response>(receivedData) ?? response;
            }
            catch (Exception ex)
            {
                response.resultMsg = $"API: {ex.Message}";
            }
            return response;
        }

        public async Task<ProductQuestionListResponse> GetProductQuestionList(ProductQuestionListRequest data)
        {
            var response = new ProductQuestionListResponse();

            try
            {
                // Product questions are public, just like the review list.
                var receivedData = await PostAsync(GET_PRODUCT_QUESTION_LIST, data, useToken: false);

                if (!string.IsNullOrWhiteSpace(receivedData))
                    return JsonConvert.DeserializeObject<ProductQuestionListResponse>(receivedData) ?? response;

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> AddProductQuestion(AddProductQuestionRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PostAsync(ADD_PRODUCT_QUESTION, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                    return JsonConvert.DeserializeObject<Response>(receivedData) ?? response;

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> AddFavoriteProduct(AddFavoriteRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PostAsync(ADD_FAVORITE_PRODUCT, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> AddCartProduct(AddCartRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PostAsync(ADD_CART_PRODUCT, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<PaymentCardListResponse> GetPaymentCardList(PaymentCardListParam data)
        {
            var response = new PaymentCardListResponse();

            try
            {
                var receivedData = await PostAsync(GET_PAYMENT_CARD_LIST, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<PaymentCardListResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }
        
        public async Task<Response> DeleteCartProduct(DeleteCartRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PostAsync(DELETE_CART_LIST, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }
        
        public async Task<ActiveSubscriptionResponse> GetActiveSubscription(ActiveSubscriptionRequest data)
        {
            var response = new ActiveSubscriptionResponse();

            try
            {
                var receivedData = await PostAsync(GET_ACTIVE_SUBSCRIPTION, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<ActiveSubscriptionResponse>(receivedData);
                    if (deserializedResponse != null)
                        return deserializedResponse;
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<SubscriptionListResponse> GetSubscriptionList(ActiveSubscriptionRequest data)
        {
            var response = new SubscriptionListResponse();

            try
            {
                var receivedData = await PostAsync(GET_SUBSCRIPTION_LIST, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<SubscriptionListResponse>(receivedData);
                    if (deserializedResponse != null)
                        return deserializedResponse;
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<TariffListResponse> GetTariffList()
        {
            var response = new TariffListResponse();

            try
            {
                var receivedData = await GetAsync(GET_TARIFF_LIST);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<TariffListResponse>(receivedData);
                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<CreateTariffCheckoutResponse> CreateTariffCheckout(CreateTariffCheckoutRequest data)
        {
            var response = new CreateTariffCheckoutResponse();

            try
            {
                var receivedData = await PostAsync(CREATE_TARIFF_CHECKOUT, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<CreateTariffCheckoutResponse>(receivedData);
                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> CancelSubscription(CancelSubscriptionRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PutAsync(CANCEL_SUBSCRIPTION, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<TariffPaymentStatusResponse> GetTariffPaymentStatus(TariffPaymentStatusRequest data)
        {
            var response = new TariffPaymentStatusResponse();

            try
            {
                var receivedData = await PostAsync(GET_TARIFF_PAYMENT_STATUS, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<TariffPaymentStatusResponse>(receivedData);
                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> DeleteOrderHistory(OrderStatusRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PutAsync(DELETE_ORDER_HISTORY, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<Response>(receivedData);

                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<CartResponse> GetCartList(CartListRequest data)
        {
            var response = new CartResponse();

            try
            {
                var receivedData = await PostAsync(GET_CART_LIST, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<CartResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> AddPaymentCard(CreatePaymentCardRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PostAsync(CREATE_PAYMENT_CARD, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> DeletePaymentCard(DeletePaymentCardRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PostAsync(DELETE_PAYMENT_CARD, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<CreateOrderResponse> CreateOrder(CreateOrderRequest data)
        {
            var response = new CreateOrderResponse();

            try
            {
                var receivedData = await PostAsync(CREATE_ORDER, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<CreateOrderResponse>(receivedData);

                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();

                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();

                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<CreatePaymeCheckoutUrlResponse> CreatePaymeCheckoutUrl(CreatePaymeCheckoutUrlRequest data)
        {
            var response = new CreatePaymeCheckoutUrlResponse();

            try
            {
                var receivedData = await PostAsync(GET_PAYME_CHEKOUT_URL, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<CreatePaymeCheckoutUrlResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<OrderPaymentStatusResponse> GetOrderPaymentStatus(OrderStatusRequest data)
        {
            var response = new OrderPaymentStatusResponse();

            try
            {
                var receivedData = await PostAsync(GET_ORDER_PAYMENT_STATUS, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<OrderPaymentStatusResponse>(receivedData);

                    if (deserializedResponse != null)
                        return deserializedResponse;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();

                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();

                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<OrderProcessResponse> GetOrderProcess(OrderStatusRequest data)
        {
            var response = new OrderProcessResponse();

            try
            {
                var receivedData = await PostAsync(GET_ORDER_PROCESS, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<OrderProcessResponse>(receivedData);

                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();

                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();

                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<OrderListResponse> GetOrderList(OrderListRequest data)
        {
            var response = new OrderListResponse();

            try
            {
                var receivedData = await PostAsync(GET_ORDER_LIST, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<OrderListResponse>(receivedData);

                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<OrderDetailResponse> GetOrderDetail(OrderStatusRequest data)
        {
            var response = new OrderDetailResponse();

            try
            {
                var receivedData = await PostAsync(GET_ORDER_DETAIL, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<OrderDetailResponse>(receivedData);

                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }


        public async Task<Response> CancelUnpaidOrder(CancelOrderRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PutAsync(CANCEL_UNPAID_ORDER, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<Response>(receivedData);

                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> CancelOrder(CancelOrderRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PutAsync(CANCEL_ORDER, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var result = JsonConvert.DeserializeObject<Response>(receivedData);

                    if (result != null)
                        return result;
                }

                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> SetDefaultPaymentCard(SetDefaultPaymentCardRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await PutAsync(SET_DEFAULT_PAYMENT_CARD, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> DeleteFavoriteProduct(DeleteFavoriteRequest data)
        {
            var response = new Response();

            try
            {
                var receivedData = await DeleteAsync(DELETE_FAVORITE_PRODUCT, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<ProductResponse> SearchProductList(SearchProductParam data)
        {
            var response = new ProductResponse();

            try
            {
                var receivedData = await PostAsync(SEARCH_PRODUCT_LIST, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<ProductResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<ProductResponse> GetFavoriteProductList(FavoriteListRequest data)
        {
            var response = new ProductResponse();

            try
            {
                var receivedData = await PostAsync(GET_FAVORITE_PRODUCT, data);

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<ProductResponse>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"API: {ex.Message}";
            }

            return response;
        }

        public async Task<Response> UpdateUserProfileInfo(Stream imageStream, Dictionary<string, string>? additionalData)
        {
            var response = new Response();

            try
            {
                var receivedData = await PostImageAsync(UPDATE_USER_INFO, imageStream, additionalData, "profile_picture_data");

                if (!string.IsNullOrWhiteSpace(receivedData))
                {
                    var deserializedResponse = JsonConvert.DeserializeObject<Response>(receivedData);
                    if (deserializedResponse != null)
                    {
                        return deserializedResponse;
                    }
                }

                response.resultMsg = ApiResult.API_SERVICE_ERROR.GetMessage();
            }
            catch (JsonException jsonEx)
            {
                response.resultCode = ApiResult.JSON_PARSING_ERROR.GetCodeToString();
                response.resultMsg = $"JSON Parsing Error: {jsonEx.Message}";
            }
            catch (Exception ex)
            {
                response.resultCode = ApiResult.API_SERVICE_ERROR.GetCodeToString();
                response.resultMsg = $"UpdateCompanyProfileInfo Error: {ex.Message}";
            }

            return response;
        }
    }
}