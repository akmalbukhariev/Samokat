using System.Collections.ObjectModel;
using System.Globalization;
using System.Text.RegularExpressions;
using Api.Services;
using Models.Dto;
using Models.Requests;
using Models.Responses;
using Ninimum.Models.Startup;
using Ninimum.Views.LoginRegister;
using Utils;
using Ninimum.Resources.Languages;

namespace Ninimum.Services
{
    public class AppControl
    {
        public bool IsBlocked = false;
        public bool IsLoggedIn { get; set; } = false;
        public bool IsAuthenticated => IsLoggedIn && CurrentUserId > 0;
        public bool IsGuest => !IsAuthenticated;
        public int CurrentUserId => userDto?.id ?? 0;

        public UserDto userDto { get; set; } = new UserDto();

        public ObservableCollection<PopupItemModel> RegionItems { get; } = new()
        {
            // Fallback values. They are replaced by /region/getRegions when the API is available.
            new() { Id = 1, Text = "Qashqadaryo" },
            new() { Id = 2, Text = "Toshkent" },
            new() { Id = 3, Text = "Samarqand" },
            new() { Id = 4, Text = "Buxoro" }
        };

        private bool regionsLoaded;

        public int SelectedRegionId { get; private set; } = 1;

        public string CurrentRegionName =>
            RegionItems.FirstOrDefault(x => x.Id == (userDto?.region_id ?? SelectedRegionId))?.Text
            ?? RegionItems.First().Text;

        public async Task LoadRegionsAsync(bool force = false)
        {
            if (regionsLoaded && !force)
                return;

            try
            {
                RegionListResponse response = await apiService.GetRegions();

                if (response.resultCode != ApiResult.SUCCESS.GetCodeToString() ||
                    response.resultData == null ||
                    response.resultData.Count == 0)
                    return;

                var regions = response.resultData
                    .Where(x => x.isActive && x.id > 0 && !string.IsNullOrWhiteSpace(x.name))
                    .OrderBy(x => x.id)
                    .ToList();

                if (regions.Count == 0)
                    return;

                RegionItems.Clear();

                foreach (var region in regions)
                {
                    RegionItems.Add(new PopupItemModel
                    {
                        Id = region.id,
                        Text = region.name
                    });
                }

                regionsLoaded = true;

                if (!RegionItems.Any(x => x.Id == SelectedRegionId))
                    SelectedRegionId = RegionItems[0].Id;

                SelectRegion(userDto?.region_id ?? SelectedRegionId);
            }
            catch
            {
                // Keep the fallback region list if the server cannot be reached.
            }
        }

        public void SelectRegion(int regionId)
        {
            if (!RegionItems.Any(x => x.Id == regionId))
                return;

            SelectedRegionId = regionId;

            foreach (var region in RegionItems)
                region.RightImage = region.Id == regionId ? "check_gray.png" : string.Empty;
        }

        public string GetRegionName(int? regionId)
        {
            return RegionItems.FirstOrDefault(x => x.Id == regionId)?.Text
                   ?? RegionItems.First().Text;
        }
        private readonly LanguageService lang;
        private readonly UserApiService apiService;
        private AppStoreService storeService;

        public AppControl(
            LanguageService lang,
            AppStoreService storeService,
            UserApiService apiService)
        {
            this.lang = lang;
            this.storeService = storeService;
            this.apiService = apiService;
            SelectRegion(SelectedRegionId);
        }

        public bool IsConnectedToWifi()
        {
            return Connectivity.NetworkAccess == NetworkAccess.Internet;
        }

        public async Task<bool> Login(string phoneNumber, string password)
        {
            var request = new LoginUserRequest
            {
                phone_number = phoneNumber,
                password = password
            };

            LoginUserResponse response = await apiService.Login(request);

            if (response.resultCode != ApiResult.SUCCESS.GetCodeToString() || response.resultData == null)
                return false;

            await InitLoginPage(response.resultData, phoneNumber, password);
            return true;
        }

        public async Task InitLoginPage(UserDto userDto,string phoneNumber, string password)
        {
            this.userDto = userDto ?? new UserDto();
            SelectRegion(this.userDto.region_id ?? SelectedRegionId);
            IsLoggedIn = true;
            IsBlocked = false;

            storeService.Set(AppKeys.IsLoggedIn, true);
            storeService.Set(AppKeys.PhoneNumber, phoneNumber);
            storeService.Set(AppKeys.Password, password);

            SetRootPage(new ContentPage
            {
                BackgroundColor = Colors.White,
                Content = new ActivityIndicator
                {
                    IsRunning = true,
                    Color = (Color)Application.Current.Resources["PrimaryColor"],
                    VerticalOptions = LayoutOptions.Center,
                    HorizontalOptions = LayoutOptions.Center
                }
            });

            await Task.Delay(100);
            
            SetRootPage(new AppShell());
        }

        public async Task StartGuestMode(bool clearSavedLogin = false)
        {
            IsLoggedIn = false;
            IsBlocked = false;
            userDto = new UserDto();

            if (clearSavedLogin)
            {
                storeService.Remove(AppKeys.IsLoggedIn);
                storeService.Remove(AppKeys.PhoneNumber);
                storeService.Remove(AppKeys.Password);
            }

            await apiService.ClearTokenAsync();
            SetRootPage(new AppShell());
        }

        public async Task<bool> EnsureAuthenticatedAsync(bool moveToHomeBeforeLogin = false)
        {
            if (IsAuthenticated)
                return true;

            if (moveToHomeBeforeLogin)
                SelectHomeTab();

            if (Shell.Current?.CurrentPage is not LoginPage)
                await AppNavigatorService.NavigateTo(nameof(LoginPage));

            return false;
        }

        private static void SelectHomeTab()
        {
            var shellItem = Shell.Current?.CurrentItem;

            if (shellItem == null || shellItem.Items.Count == 0)
                return;

            shellItem.CurrentItem = shellItem.Items[0];
        }

        public async Task Logout(bool isBlocked = true)
        {
            IsBlocked = isBlocked;

            Response response = await apiService.LogOut();
            if (response.resultCode == ApiResult.SUCCESS.GetCodeToString())
            {
                //do something
            }

            storeService.Remove(AppKeys.IsLoggedIn);
            storeService.Remove(AppKeys.PhoneNumber);
            storeService.Remove(AppKeys.Password);

            IsLoggedIn = false;
            userDto = new UserDto();

            await apiService.ClearTokenAsync();

            // After logout the user continues browsing as a guest.
            SetRootPage(new AppShell());
        }

        public async Task<string?> SendVerificationCode(string phoneNumber)
        {
            try
            {
                var data = new VerifyPhoneNumberRequest
                {
                    phone_number = phoneNumber
                };

                VerifyPhoneNumberResponse response =
                    await apiService.VerifyNumber(data);

                if (response?.resultCode == ApiResult.SUCCESS.GetCodeToString())
                {
                    return response.resultData.code;
                }

                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public void SetRootPage(Page page)
        {
            var window = Application.Current?.Windows.FirstOrDefault();
            if (window == null) return;

            // If you call this from a background thread, force UI thread:
            MainThread.BeginInvokeOnMainThread(() =>
            {
                window.Page = page;
            });
        }

        public void ShowTabBar(bool show)
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                var page = Shell.Current?.CurrentPage;

                if (page != null)
                {
                    Shell.SetTabBarIsVisible(page, show);
                }
            });
        }

        public bool IsValidUzbekistanPhoneNumber(string phoneNumber)
        {
            if (string.IsNullOrWhiteSpace(phoneNumber))
                return false;

            phoneNumber = phoneNumber.Trim();

            const string PHONE_PATTERN = @"^998(90|91|93|94|50|77|95|99|87|88|97|98|33|20)\d{7}$";

            return Regex.IsMatch(phoneNumber, PHONE_PATTERN);
        }
         
        public string GetUzbCurrency(decimal? price)
        {
            var uz = new CultureInfo("uz-UZ");
            return string.Format(uz, AppResource.UZS_02854f, price);
        }

#region Check url image
        private readonly string[] AllowedBases =
        {
            $"http://{AppConstants.SERVER_DOMAIN}/uploads-user/profile-pictures/",
            $"http://{AppConstants.SERVER_DOMAIN}/uploads-company/profile-pictures/",
            $"http://{AppConstants.SERVER_DOMAIN}/uploads-company/poster-pictures/"
        };

        public string GetImageUrlOrFallback(string? imageUrl, string fallback = "no_image.png")
        {
            if (string.IsNullOrWhiteSpace(imageUrl))
                return fallback;

            // Must be a valid absolute http/https URL
            if (!Uri.TryCreate(imageUrl, UriKind.Absolute, out var uri) ||
                (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps))
            {
                return fallback;
            }

            // Normalize for comparison (ignore trailing '/')
            string normUrl = TrimEndSlash(uri.ToString());
            var normBases = AllowedBases.Select(TrimEndSlash).ToArray();

            // Case 1: exactly the base path (no filename) -> fallback
            if (normBases.Any(b => string.Equals(normUrl, b, StringComparison.OrdinalIgnoreCase)))
                return fallback;

            // Case 2: must start with one of the bases AND have something after it (a file part)
            bool hasAllowedPrefixWithFile = normBases.Any(b =>
                normUrl.StartsWith(b, StringComparison.OrdinalIgnoreCase) &&
                normUrl.Length > b.Length); // ensures there's more than the base

            if (!hasAllowedPrefixWithFile)
                return fallback;

            return imageUrl;
        }

        private string TrimEndSlash(string s) => s.TrimEnd('/');
#endregion
        
#region Photo
        public async Task<FileResult?> TryPickPhotoAsync()
        {
            try
            {   
                if (!await EnsureGalleryPermissionAsync())
                    return null;

                return await MediaPicker.PickPhotoAsync();
            }
            catch (OperationCanceledException) { return null; }
            catch (PermissionException) { return null; }
        }

        public async Task<FileResult?> TryCapturePhotoAsync()
        {
            try
            {
                if (!MediaPicker.Default.IsCaptureSupported)
                    return null;

                // ✅ Ensure permission first (prevents crash + gives user guidance)
                if (!await EnsureCameraPermissionAsync())
                    return null;

                return await MediaPicker.CapturePhotoAsync();
            }
            catch (OperationCanceledException) { return null; }
            catch (PermissionException) { return null; }
        }

        public async Task<bool> EnsureGalleryPermissionAsync()
        {
        #if IOS
            var status = await Permissions.CheckStatusAsync<Permissions.Photos>();

            if (status == PermissionStatus.Granted)
                return true;

            if (status == PermissionStatus.Limited)
            {
                await AskUserToGrantFullPhotoAccess();
                return false;
            }

            status = await Permissions.RequestAsync<Permissions.Photos>();

            if (status == PermissionStatus.Granted)
                return true;

            if (status == PermissionStatus.Limited)
            {
                await AskUserToGrantFullPhotoAccess();
                return false;
            }

            await AskUserToGrantFullPhotoAccess();
            return false;
        #else
            // Android: your existing logic
            var status = await Permissions.CheckStatusAsync<Permissions.StorageRead>();
            if (status != PermissionStatus.Granted)
                status = await Permissions.RequestAsync<Permissions.StorageRead>();
            return status == PermissionStatus.Granted;
        #endif
        }

        private async Task AskUserToGrantFullPhotoAccess()
        {
            bool openSettings = await Shell.Current.DisplayAlert(
                AppResource.PermissionRequired,
                AppResource.MessagePermissionRequired,
                AppResource.OpenSettings,
                AppResource.Cancel);

            if (openSettings)
            {
                // This opens the app's settings page directly
                AppInfo.ShowSettingsUI();
            }
        }
        
        public async Task<bool> EnsureCameraPermissionAsync()
        {
        #if IOS
            var status = await Permissions.CheckStatusAsync<Permissions.Camera>();

            // Already granted ✅
            if (status == PermissionStatus.Granted)
                return true;

            // If previously denied/restricted, no point re-asking — go straight to settings
            if (status == PermissionStatus.Denied || status == PermissionStatus.Restricted)
            {
                await AskUserToGrantFullPhotoAccess();
                return false;
            }

            // First-time/unknown → request it
            status = await Permissions.RequestAsync<Permissions.Camera>();

            if (status == PermissionStatus.Granted)
                return true;

            // Still not granted → ask user to open Settings
            await AskUserToGrantFullPhotoAccess();
            return false;

        #elif ANDROID
            var status = await Permissions.CheckStatusAsync<Permissions.Camera>();

            if (status == PermissionStatus.Granted)
                return true;

            status = await Permissions.RequestAsync<Permissions.Camera>();

            if (status == PermissionStatus.Granted)
                return true;

            // User denied (maybe checked "Don't ask again") → suggest opening settings
            await AskUserToGrantFullPhotoAccess();
            return false;

        #else
            // Other platforms: treat as granted
            return true;
        #endif
        }

#endregion
    }
}
