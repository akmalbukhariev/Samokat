using Microsoft.Extensions.Logging;
using CommunityToolkit.Maui;
using Ninimum.Services;
using Ninimum.Services.Interface;
using Xe.AcrylicView;
using Ninimum.ViewModels;
using Ninimum.Views.Main;
using Ninimum.Views.Search;
using Ninimum.Views.DetailProduct;
using Ninimum.Views.FavoriteProduct;
using Ninimum.Views.Formalization;
using Ninimum.Views.PaymentCard;
using Ninimum.Views.Children;
using Ninimum.Views.Profile;
using Api.Services;
using Ninimum.Views.LoginRegister;
using RestSharp;
using Utils;
using Ninimum.Views.Authorization;
using Ninimum.Views.Cart;
using Ninimum.Views.Payment;
using Ninimum.Views.Orders;
using Ninimum.Views.MyTariff;
using Ninimum.Views.Startup;

#if ANDROID

#elif IOS
using UIKit;
using Foundation;
#endif

namespace Ninimum;

public static class MauiProgram
{
	public static MauiApp CreateMauiApp()
	{
		var builder = MauiApp.CreateBuilder();
		builder
			.UseMauiApp<App>()
			.UseAcrylicView()
			.UseMauiMaps()
			.UseMauiCommunityToolkit()
			.ConfigureFonts(fonts =>
			{
				fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
				fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");

				fonts.AddFont("SFPRODISPLAYREGULAR.OTF", "SFRegular");
				fonts.AddFont("SFPRODISPLAYMEDIUM.OTF", "SFMedium");
				fonts.AddFont("SFPRODISPLAYBOLD.OTF", "SFBold");
				fonts.AddFont("SansitaOne.ttf", "SansitaOne");
			});

#if DEBUG
		builder.Logging.AddDebug();
#endif
		RegisterSingleton(builder);
		RegisterTransient(builder);

		var mauiApp = builder.Build();
		AppService.Init(mauiApp.Services);

		return mauiApp;
	}

	private static void RegisterSingleton(MauiAppBuilder builder)
	{
		builder.Services.AddSingleton<AppStoreService>();
		builder.Services.AddSingleton<AppControl>();
		builder.Services.AddSingleton<LanguageService>();
		builder.Services.AddSingleton<ConnectionMonitorService>();
		builder.Services.AddSingleton<UserApiService>();
		builder.Services.AddSingleton(sp =>
                new RestClient(new RestClientOptions(AppConstants.BASE_USER_URL)
                {
                    ThrowOnAnyError = false,
                    Timeout = TimeSpan.FromSeconds(30)
                }));

#if ANDROID
		builder.Services.AddSingleton<IStatusBarService, Ninimum.Platforms.Android.StatusBarService>();
		//builder.Services.AddSingleton<INotificationService, NotificationService>();
		builder.Services.AddSingleton<IKeyboardHelper, KeyboardHelper>();
#endif

#if IOS
		builder.Services.AddSingleton<IStatusBarService, Ninimum.Platforms.iOS.StatusBarService>();
		//builder.Services.AddSingleton<IKeyboardHelper, EcoPlatesMobile.Platforms.iOS.KeyboardHelper>();
#endif
	}

	private static void RegisterTransient(MauiAppBuilder builder)
	{
		builder.Services.AddTransient<StartPage>();
		builder.Services.AddTransient<OnboardingPage>();
		builder.Services.AddTransient<LoginPage>();
		builder.Services.AddTransient<MainPage>();
		builder.Services.AddTransient<MenuPage>();
		builder.Services.AddTransient<SearchPage>();
		builder.Services.AddTransient<DetailProductPage>();
		builder.Services.AddTransient<ProductReviews>();
		builder.Services.AddTransient<LeaveCommentPage>();
		builder.Services.AddTransient<ProductQuestionsPage>();
		builder.Services.AddTransient<AskProductQuestionPage>();
		builder.Services.AddTransient<FavoritePage>();
		builder.Services.AddTransient<CartPage>();
		builder.Services.AddTransient<FormalizationPage>();
		builder.Services.AddTransient<PaymentCardPage>();
		builder.Services.AddTransient<CancelOrderPage>();
		builder.Services.AddTransient<AddPaymentCardPage>();
		builder.Services.AddTransient<ChildInfoPage>();
		builder.Services.AddTransient<MyProfilePage>();
		builder.Services.AddTransient<DeleteAccountPage>();
		builder.Services.AddTransient<AuthorizationPage>();
		builder.Services.AddTransient<AddressPage>();
		builder.Services.AddTransient<PaymentPage>();
		builder.Services.AddTransient<OrdersPage>();
		builder.Services.AddTransient<MyTariffPage>();
		builder.Services.AddTransient<TariffsPage>();
		builder.Services.AddTransient<Ninimum.Views.ChangePhoneNumber.ChangePhoneNumberPage>();
		builder.Services.AddTransient<Ninimum.Views.ChangePassword.ChangePasswordPage>();

		builder.Services.AddTransient<MainPageViewModel>();
		builder.Services.AddTransient<MenuPageViewModel>();
		builder.Services.AddTransient<SearchPageViewModel>();
		builder.Services.AddTransient<DetailProductPageViewModel>();
		builder.Services.AddTransient<ProductReviewsViewModel>();
		builder.Services.AddTransient<ProductQuestionsViewModel>();
		builder.Services.AddTransient<AskProductQuestionViewModel>();
		builder.Services.AddTransient<FavoritePageViewModel>();
		builder.Services.AddTransient<CartPageViewModel>();
		builder.Services.AddTransient<LoginPageViewModel>();
		builder.Services.AddTransient<RegisterPageViewModel>();
		builder.Services.AddTransient<OrdersPageViewModel>();

		builder.Services.AddTransient(sp =>
                new UserApiService(
                    sp.GetServices<RestClient>().First(rc => rc.Options.BaseUrl == new Uri(AppConstants.BASE_USER_URL))
                ));
	}
}
