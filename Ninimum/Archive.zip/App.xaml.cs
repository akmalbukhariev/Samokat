using Microsoft.Maui.Handlers;
using Microsoft.Maui.Platform;
using Ninimum.Services;
using Ninimum.Views.Authorization;
using Ninimum.Views.ChangePhoneNumber;
using Ninimum.Views.DetailProduct;
using Ninimum.Views.Formalization;
using Ninimum.Views.LoginRegister;
using Ninimum.Views.Main;
using Ninimum.Views.MyTariff;
using Ninimum.Views.Orders;
using Ninimum.Views.Payment;
using Ninimum.Views.PaymentCard;
using Ninimum.Views.Profile;
using Ninimum.Views.Search;
using Ninimum.Views.Startup;

namespace Ninimum;

public partial class App : Application
{
    public App()
    {
        InitializeComponent();
        
        RegisterRoutes();
        Setting();
    }

    protected override Window CreateWindow(IActivationState? activationState)
    {
        AppService.GetRequired<LanguageService>().Init();

        var window = new Window(new AppEntryShell());
        var connectionMonitor = AppService.Get<ConnectionMonitorService>();

        window.Activated += (_, _) => connectionMonitor?.Start();
        window.Resumed += (_, _) => connectionMonitor?.Start();
        window.Stopped += (_, _) => connectionMonitor?.Stop();
        window.Destroying += (_, _) => connectionMonitor?.Stop();

        return window;
    }

    private void RegisterRoutes()
    {
        #region Startup pages
        Routing.RegisterRoute(nameof(StartPage), typeof(StartPage));
        Routing.RegisterRoute(nameof(OnboardingPage), typeof(OnboardingPage));
        Routing.RegisterRoute(nameof(RegisterPage), typeof(RegisterPage));
        Routing.RegisterRoute(nameof(LoginPage), typeof(LoginPage));
        Routing.RegisterRoute(nameof(ForgotPasswordPage), typeof(ForgotPasswordPage));
        Routing.RegisterRoute(nameof(AuthorizationPage), typeof(AuthorizationPage));
        Routing.RegisterRoute(nameof(AddressPage), typeof(AddressPage));
        Routing.RegisterRoute(nameof(ChangePasswordPage), typeof(ChangePasswordPage));
        Routing.RegisterRoute(nameof(ChangePhoneNumberPage), typeof(ChangePhoneNumberPage));
        Routing.RegisterRoute("ProfileChangePasswordPage", typeof(Ninimum.Views.ChangePassword.ChangePasswordPage));
        #endregion

        #region Main pages
        Routing.RegisterRoute(nameof(MainPage), typeof(MainPage));
        Routing.RegisterRoute(nameof(MenuPage), typeof(MenuPage));
        Routing.RegisterRoute(nameof(SearchPage), typeof(SearchPage));
        Routing.RegisterRoute(nameof(DetailProductPage), typeof(DetailProductPage));
        Routing.RegisterRoute(nameof(ProductReviews), typeof(ProductReviews));
        Routing.RegisterRoute(nameof(LeaveCommentPage), typeof(LeaveCommentPage));
        Routing.RegisterRoute(nameof(ProductQuestionsPage), typeof(ProductQuestionsPage));
        Routing.RegisterRoute(nameof(AskProductQuestionPage), typeof(AskProductQuestionPage));
        Routing.RegisterRoute(nameof(FormalizationPage), typeof(FormalizationPage));
        Routing.RegisterRoute(nameof(AddPaymentCardPage), typeof(AddPaymentCardPage));
        Routing.RegisterRoute(nameof(CancelOrderPage), typeof(CancelOrderPage));
        Routing.RegisterRoute(nameof(PaymentCardPage), typeof(PaymentCardPage));
        Routing.RegisterRoute(nameof(PaymentPage), typeof(PaymentPage));
        Routing.RegisterRoute(nameof(OrdersPage), typeof(OrdersPage));
        Routing.RegisterRoute(nameof(MyTariffPage), typeof(MyTariffPage));
        Routing.RegisterRoute(nameof(TariffsPage), typeof(TariffsPage));
        Routing.RegisterRoute(nameof(DeleteAccountPage), typeof(DeleteAccountPage));
        #endregion
    }

	private void Setting()
    {
#if ANDROID
        Microsoft.Maui.Handlers.EntryHandler.Mapper.AppendToMapping(nameof(Entry), (handler, view) =>
        {
            handler.PlatformView.BackgroundTintList =
                Android.Content.Res.ColorStateList.ValueOf(Colors.Transparent.ToPlatform());
        });

        Microsoft.Maui.Handlers.PickerHandler.Mapper.AppendToMapping(nameof(Picker), (handler, view) =>
        {
            handler.PlatformView.BackgroundTintList =
                Android.Content.Res.ColorStateList.ValueOf(Colors.Transparent.ToPlatform());
        });

        Microsoft.Maui.Handlers.DatePickerHandler.Mapper.AppendToMapping(nameof(DatePicker), (handler, view) =>
        {
            handler.PlatformView.BackgroundTintList =
                Android.Content.Res.ColorStateList.ValueOf(Colors.Transparent.ToPlatform());
        });

        Microsoft.Maui.Handlers.TimePickerHandler.Mapper.AppendToMapping(nameof(TimePicker), (handler, view) =>
        {
            handler.PlatformView.BackgroundTintList =
                Android.Content.Res.ColorStateList.ValueOf(Colors.Transparent.ToPlatform());
        });

        EditorHandler.Mapper.AppendToMapping("NoUnderline", (handler, view) =>
        {
            if (handler.PlatformView is Android.Widget.EditText editText)
            {
                editText.Background = null; // Removes underline
            }
        });
#endif

#if IOS    
        EntryHandler.Mapper.AppendToMapping(nameof(Entry), (handler, view) =>
        {
            handler.PlatformView.BorderStyle = UITextBorderStyle.None;
            handler.PlatformView.Layer.BorderWidth = 0;
            handler.PlatformView.BackgroundColor = UIColor.Clear;
        });

        PickerHandler.Mapper.AppendToMapping(nameof(Picker), (handler, view) =>
        {
            handler.PlatformView.BorderStyle = UITextBorderStyle.None;
            handler.PlatformView.Layer.BorderWidth = 0;
            handler.PlatformView.BackgroundColor = UIColor.Clear;
        });

        DatePickerHandler.Mapper.AppendToMapping(nameof(DatePicker), (handler, view) =>
        {
            handler.PlatformView.BorderStyle = UITextBorderStyle.None;
            handler.PlatformView.Layer.BorderWidth = 0;
            handler.PlatformView.BackgroundColor = UIColor.Clear;
        });

        TimePickerHandler.Mapper.AppendToMapping(nameof(TimePicker), (handler, view) =>
        {
            handler.PlatformView.BorderStyle = UITextBorderStyle.None;
            handler.PlatformView.Layer.BorderWidth = 0;
            handler.PlatformView.BackgroundColor = UIColor.Clear;
        });

        EditorHandler.Mapper.AppendToMapping("NoBorder", (handler, view) =>
        {
            // Editor is UITextView on iOS
            var textView = handler.PlatformView;
            textView.Layer.BorderWidth = 0;
            textView.BackgroundColor = UIColor.Clear;
        });
#endif
    }
}
